# AUS GYM booking website

A React/Vite frontend + Express API, Razorpay Checkout, and Supabase/PostgreSQL storage. The app is intentionally configured to **fail closed**: payment cannot be confirmed unless Razorpay signature verification succeeds on the server. No payment success is simulated.

## Requirements
- Node.js 20+
- A Supabase project
- A Razorpay account (start with test keys; activate live payments with Razorpay before accepting real money)

## 1. Database setup
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `server/supabase/schema.sql`.
3. Copy the project URL and **service role** key from Project Settings → API. The service role key belongs only on the server; never put it in client env vars.

## 2. Razorpay setup
1. Create/sign in at https://razorpay.com and open Account & Settings → API Keys.
2. Generate **test mode** key ID and secret first.
3. Add them to `server/.env` below. Test with Razorpay test payment methods before switching to live keys.
4. In Razorpay settings, configure the webhook URL as `https://YOUR-API-DOMAIN/api/payments/webhook` and subscribe to `payment.captured` and `payment.failed`. Put the webhook secret in `RAZORPAY_WEBHOOK_SECRET`.
5. Do not use live keys until the account is approved and the full flow has been tested. Never share `.env` or commit it.

## 3. Environment variables
Copy `server/.env.example` to `server/.env` and fill in values. Copy `client/.env.example` to `client/.env` and set the public API URL (local default is fine). `SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_SECRET`, and webhook secret must never be exposed to the browser.

## 4. Install and run locally
From the project root:
```bash
npm install
npm install --prefix client
npm install --prefix server
cp server/.env.example server/.env
cp client/.env.example client/.env
npm run dev
```
Frontend: http://localhost:5173; API: http://localhost:8080. Add actual credentials before expecting database/payment actions to work.

## 5. First admin account
The admin dashboard uses Supabase Auth. In Supabase → Authentication → Users, create an admin user. Then in SQL Editor run:
```sql
insert into public.admin_users (user_id) values ('PASTE_AUTH_USER_UUID_HERE');
```
Only users listed in `admin_users` are authorized to access admin APIs. Keep the admin account private and use a strong password.

## 6. Deploy
- **API:** deploy `server/` to a Node.js host such as Render, Railway, or a VPS. Set all variables from `server/.env.example` in the host's secret/environment settings. Set `CLIENT_ORIGIN` to the deployed frontend origin. Set `PORT` per host. Configure HTTPS.
- **Frontend:** run `npm run build --prefix client`; deploy `client/dist` to a static host such as Vercel or Netlify. Set `VITE_API_BASE_URL` to the HTTPS API origin before building.
- Update Razorpay webhook URL to the deployed API URL and configure webhook secret.
- Configure CORS to the exact production frontend origin; don't use `*` in production.
- Test booking creation, payment failure, successful captured payment, duplicate callbacks, admin login, CSV export, and mobile layout using test mode before switching to live mode.

## Important production notes
- A booking is marked paid only after server-side signature verification from the checkout response or a verified `payment.captured` webhook. The webhook handler is idempotent.
- A booking starts as `pending`; abandoned or failed attempts remain unpaid. Consider adding a scheduled cleanup job for old pending bookings.
- This starter sends no confirmation email until an email provider is configured. It displays confirmation after verified payment.
- The location is intentionally the provided general address only: Madhepura, Bihar, India – 852113. No street address, opening hours, or phone number is invented.
- Have a qualified developer/security reviewer audit deployment, rate limits, backups, privacy notice, retention, and refund/cancellation policy before production use.
