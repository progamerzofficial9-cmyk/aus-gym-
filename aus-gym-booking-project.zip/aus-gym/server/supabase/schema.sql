create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_code text unique not null,
  full_name text not null check (char_length(full_name) between 2 and 100),
  phone text not null check (phone ~ '^[6-9][0-9]{9}$'),
  email text not null,
  booking_date date not null,
  time_slot text not null,
  amount_paise integer not null default 10000 check (amount_paise = 10000),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  booking_status text not null default 'confirmed' check (booking_status in ('confirmed','cancelled')),
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists bookings_date_idx on public.bookings(booking_date);
create index if not exists bookings_name_idx on public.bookings using gin (to_tsvector('simple', full_name));

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.bookings enable row level security;
alter table public.admin_users enable row level security;
-- No public policies: all booking/admin data access goes through the server's service-role client.
