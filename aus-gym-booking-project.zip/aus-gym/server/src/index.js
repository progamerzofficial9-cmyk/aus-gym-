import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import Razorpay from 'razorpay';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';
import crypto from 'node:crypto';

const app = express();
const PORT = Number(process.env.PORT || 8080);
const requiredEnv = ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','RAZORPAY_KEY_ID','RAZORPAY_KEY_SECRET'];
const missing = requiredEnv.filter(k => !process.env[k] || process.env[k].includes('replace_me'));
const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { autoRefreshToken: false, persistSession: false } }) : null;
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map(x => x.trim()), credentials: true }));
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '30kb' }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
const bookingLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, message: { error: 'Too many booking attempts. Please try again later.' } });

const bookingSchema = z.object({
  fullName: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit Indian mobile number.'),
  email: z.string().trim().email().max(254),
  bookingDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  timeSlot: z.enum(['06:00 AM - 08:00 AM','08:00 AM - 10:00 AM','10:00 AM - 12:00 PM','04:00 PM - 06:00 PM','06:00 PM - 08:00 PM','08:00 PM - 10:00 PM']),
  website: z.string().max(0).optional() // honeypot; must be empty
});
const configured = () => { if (missing.length || !supabase || !razorpay) throw Object.assign(new Error('Booking services are not configured yet. Please contact AUS GYM.'), { status: 503 }); };
const makeCode = () => `AUS-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
const validDate = (date) => { const d = new Date(`${date}T00:00:00+05:30`); const today = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })); today.setHours(0,0,0,0); return !Number.isNaN(d.getTime()) && d >= today; };

app.get('/api/health', (_req,res) => res.json({ ok: true, configured: missing.length === 0 && Boolean(supabase && razorpay), missing: process.env.NODE_ENV === 'production' ? undefined : missing }));

app.post('/api/bookings/create-order', bookingLimiter, async (req,res,next) => {
  try {
    configured();
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Please check your booking details.' });
    if (parsed.data.website) return res.status(400).json({ error: 'Invalid request.' });
    if (!validDate(parsed.data.bookingDate)) return res.status(400).json({ error: 'Please choose today or a future date.' });
    const { fullName, phone, email, bookingDate, timeSlot } = parsed.data;
    const bookingCode = makeCode();
    const order = await razorpay.orders.create({ amount: 10000, currency: 'INR', receipt: bookingCode, notes: { booking_code: bookingCode } });
    const { data, error } = await supabase.from('bookings').insert({ booking_code: bookingCode, full_name: fullName, phone, email, booking_date: bookingDate, time_slot: timeSlot, amount_paise: 10000, payment_status: 'pending', booking_status: 'confirmed', razorpay_order_id: order.id }).select('booking_code,booking_date,time_slot,amount_paise').single();
    if (error) { await razorpay.orders.fetch(order.id).catch(()=>{}); throw error; }
    res.json({ keyId: process.env.RAZORPAY_KEY_ID, orderId: order.id, amount: 10000, currency: 'INR', booking: { bookingId: data.booking_code, date: data.booking_date, timeSlot: data.time_slot, amount: 100 } });
  } catch (e) { next(e); }
});

app.post('/api/payments/verify', bookingLimiter, async (req,res,next) => {
  try {
    configured();
    const schema = z.object({ razorpay_order_id: z.string().min(1), razorpay_payment_id: z.string().min(1), razorpay_signature: z.string().min(1), bookingId: z.string().min(1) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Payment verification details are incomplete.' });
    const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature, bookingId } = parsed.data;
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');
    const a = Buffer.from(expected); const b = Buffer.from(signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return res.status(400).json({ error: 'Payment could not be verified. Do not retry if money was deducted; contact the gym with your payment reference.' });
    const payment = await razorpay.payments.fetch(paymentId);
    if (payment.order_id !== orderId || payment.amount !== 10000 || payment.currency !== 'INR' || !['captured','authorized'].includes(payment.status)) return res.status(400).json({ error: 'Payment is not captured or the amount does not match.' });
    if (payment.status !== 'captured') return res.status(409).json({ error: 'Payment is not captured yet. Please wait a moment and check again.' });
    const { data, error } = await supabase.from('bookings').update({ payment_status: 'paid', razorpay_payment_id: paymentId, paid_at: new Date().toISOString() }).eq('booking_code', bookingId).eq('razorpay_order_id', orderId).neq('payment_status','paid').select('booking_code,full_name,booking_date,time_slot,amount_paise,payment_status,razorpay_payment_id').maybeSingle();
    if (error) throw error;
    if (!data) {
      const existing = await supabase.from('bookings').select('booking_code,full_name,booking_date,time_slot,amount_paise,payment_status,razorpay_payment_id').eq('booking_code', bookingId).eq('razorpay_order_id', orderId).maybeSingle();
      if (existing.data?.payment_status === 'paid' && existing.data.razorpay_payment_id === paymentId) return res.json({ ok: true, booking: publicBooking(existing.data) });
      return res.status(404).json({ error: 'Booking could not be matched to this payment.' });
    }
    res.json({ ok: true, booking: publicBooking(data) });
  } catch (e) { next(e); }
});
function publicBooking(b) { return { bookingId: b.booking_code, name: b.full_name, date: b.booking_date, timeSlot: b.time_slot, amount: b.amount_paise / 100, paymentStatus: b.payment_status }; }

// Razorpay webhooks are authenticated using the raw request body and a dedicated webhook secret.
app.post('/api/payments/webhook', async (req,res,next) => {
  try {
    configured();
    if (!process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(503).send('Webhook secret is not configured');
    const signature = req.get('x-razorpay-signature') || '';
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET).update(req.body).digest('hex');
    const a = Buffer.from(expected); const b = Buffer.from(signature);
    if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return res.status(400).send('Invalid signature');
    const event = JSON.parse(req.body.toString('utf8'));
    if (event.event === 'payment.captured') {
      const p = event.payload?.payment?.entity;
      if (p?.order_id && p?.id && p.amount === 10000 && p.currency === 'INR' && p.status === 'captured') {
        await supabase.from('bookings').update({ payment_status: 'paid', razorpay_payment_id: p.id, paid_at: new Date().toISOString() }).eq('razorpay_order_id', p.order_id).neq('payment_status','paid');
      }
    } else if (event.event === 'payment.failed') {
      const p = event.payload?.payment?.entity;
      if (p?.order_id) await supabase.from('bookings').update({ payment_status: 'failed' }).eq('razorpay_order_id', p.order_id).eq('payment_status','pending');
    }
    res.json({ received: true });
  } catch (e) { next(e); }
});

async function requireAdmin(req,res,next) {
  try {
    configured();
    const token = (req.get('authorization') || '').replace(/^Bearer\s+/i,'');
    if (!token) return res.status(401).json({ error: 'Please log in.' });
    const { data: userData, error: authError } = await supabase.auth.getUser(token);
    if (authError || !userData.user) return res.status(401).json({ error: 'Session expired. Please log in again.' });
    const { data, error } = await supabase.from('admin_users').select('user_id').eq('user_id', userData.user.id).maybeSingle();
    if (error) throw error;
    if (!data) return res.status(403).json({ error: 'Admin access is not enabled for this account.' });
    req.admin = userData.user; next();
  } catch (e) { next(e); }
}
app.get('/api/admin/bookings', requireAdmin, async (req,res,next) => {
  try {
    const search = String(req.query.search || '').trim().slice(0,100);
    const date = String(req.query.date || '').trim();
    let q = supabase.from('bookings').select('*').order('created_at',{ascending:false}).limit(1000);
    if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) q = q.eq('booking_date',date);
    if (search) q = q.or(`full_name.ilike.%${search.replace(/[,%()]/g,'')}%,phone.ilike.%${search.replace(/[,%()]/g,'')}%,booking_code.ilike.%${search.replace(/[,%()]/g,'')}%`);
    const { data, error } = await q; if (error) throw error;
    res.json({ bookings: data || [], totalBookings: data?.length || 0, verifiedRevenue: (data || []).filter(x => x.payment_status === 'paid').reduce((n,x)=>n+x.amount_paise,0)/100 });
  } catch(e) { next(e); }
});
app.patch('/api/admin/bookings/:id/status', requireAdmin, async (req,res,next) => {
  try {
    const parsed = z.object({ bookingStatus: z.enum(['confirmed','cancelled']) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid booking status.' });
    const { data, error } = await supabase.from('bookings').update({ booking_status: parsed.data.bookingStatus }).eq('booking_code',req.params.id).select('booking_code,booking_status').single();
    if (error) throw error; res.json({ booking: data });
  } catch(e) { next(e); }
});
app.get('/api/admin/bookings.csv', requireAdmin, async (_req,res,next) => {
  try {
    const { data, error } = await supabase.from('bookings').select('*').order('created_at',{ascending:false}).limit(10000); if(error) throw error;
    const cols = ['booking_code','full_name','phone','email','booking_date','time_slot','amount_paise','payment_status','booking_status','razorpay_payment_id','created_at','paid_at'];
    const esc = v => `"${String(v ?? '').replaceAll('"','""')}"`;
    const csv = [cols.join(','), ...(data||[]).map(r=>cols.map(c=>esc(r[c])).join(','))].join('\r\n');
    res.setHeader('Content-Type','text/csv; charset=utf-8'); res.setHeader('Content-Disposition','attachment; filename="aus-gym-bookings.csv"'); res.send(csv);
  } catch(e) { next(e); }
});
app.use((err,_req,res,_next) => { console.error(err); res.status(err.status || 500).json({ error: err.status ? err.message : 'Something went wrong. Please try again.' }); });
app.listen(PORT, () => console.log(`AUS GYM API listening on ${PORT}; missing config: ${missing.join(', ') || 'none'}`));
